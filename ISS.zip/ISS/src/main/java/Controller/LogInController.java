package Controller;

import Domain.Angajat;
import Service.Service;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class LogInController {
    Stage stage;
    private Service service;
    @FXML
    TextField user;

    @FXML
    TextField parola;

    @FXML
    TextField ora;

    @FXML
    Button login;


    public void setService(Service service, Stage stage1) {
        this.stage = stage1;
        this.service=service;

    }

    public void Intrare(ActionEvent actionEvent) {
        String usw=user.getText();
        String pw=parola.getText();
        String orw=ora.getText();
        if(service.login(usw,pw,orw)==null)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Userul sau parola utilizatorului sunt gresite", ButtonType.OK);
            alert.setResizable(true);
            alert.show();
            user.setText("");
            parola.setText("");
            ora.setText("");
        }
        else
        {
            Angajat a=service.login(usw,pw,orw);
            if(a.getRol().equals("angajat"))
            {
                try {
                    FXMLLoader loader = new FXMLLoader();
                    loader.setLocation(getClass().getResource("/FereastraAngajat.fxml"));
                    AnchorPane root = loader.load();
                    FereastraAngajatController fereastraAngajatController = loader.getController();
                    Stage newstage = new Stage();
                    newstage.setScene(new Scene(root, 684, 495, Color.TRANSPARENT));
                    newstage.setTitle(a.getNume());
                    fereastraAngajatController.setService(service,newstage,this.stage,a);
                    this.stage.hide();
                    newstage.show();
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
            else
            {
                try {
                    FXMLLoader loader = new FXMLLoader();
                    loader.setLocation(getClass().getResource("/FereastraSef.fxml"));
                    AnchorPane root = loader.load();
                    FereastraSefController fereastraSefController = loader.getController();
                    Stage newstage = new Stage();
                    newstage.setScene(new Scene(root, 684, 495, Color.TRANSPARENT));
                    newstage.setTitle(a.getNume());
                    fereastraSefController.setService(service,newstage,this.stage,a);
                    this.stage.hide();
                    newstage.show();
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        }




    }
}
