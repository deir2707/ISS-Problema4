package Controller;

import Domain.Angajat;
import Service.Observer;
import Service.Service;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.Arrays;
import java.util.List;

public class FereastraAngajatController  implements Observer {
    Stage stage;
    private Service service;
    Stage back;
    Angajat a;

    @FXML
    Button logout;
    public void setService(Service service, Stage stage1, Stage back, Angajat a) {
        this.stage = stage1;
        this.service=service;
        this.back=back;
        this.a=a;
        this.service.addObserver(this);

    }

    public void deconectare(ActionEvent actionEvent) {
        try{
            String[] cv=a.getDate().split(";");
            service.logout(a,cv[1]);
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("/Login.fxml"));
            AnchorPane root=loader.load();
            LogInController logInController=loader.getController();
            this.back.setScene(new Scene(root,600,400, Color.TRANSPARENT));
            this.back.setTitle("App");
            logInController.setService(service,this.back);
            this.stage.hide();
            this.back.show();
        }
        catch(Exception e)
        {
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error ");
            alert.setContentText("Error while starting app "+e);
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    @Override
    public void update() {

    }
}
