package Repository.interfaces;


import Domain.Task;

public interface RepositoryTask extends Repository<Long, Task> {
    Iterable<Task> findDupaIdAngajatului(Long id,String stare);
}
