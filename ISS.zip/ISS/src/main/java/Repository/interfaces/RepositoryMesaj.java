package Repository.interfaces;

import Domain.Mesaj;
import Domain.Task;

public interface RepositoryMesaj extends Repository<Long, Mesaj>{
    Iterable<Mesaj> findAllID(Long ang);
}
