package Repository.interfaces;

import Domain.Angajat;

public interface RepositoryAngajat extends Repository<Long, Angajat> {
    Angajat findAngajat(String user,String pw,String data);
}
