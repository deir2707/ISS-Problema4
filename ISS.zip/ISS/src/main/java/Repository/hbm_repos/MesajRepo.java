package Repository.hbm_repos;

import Domain.Angajat;
import Domain.Mesaj;
import Domain.Task;
import Repository.interfaces.RepositoryMesaj;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.ArrayList;
import java.util.List;

public class MesajRepo implements RepositoryMesaj {
    @Override
    public Mesaj findOne(Long aLong) {
        return null;
    }
    private static SessionFactory sessionFactory;


    public MesajRepo( SessionFactory sessionFactory)
    {
        MesajRepo.sessionFactory = sessionFactory;
    }

    static void close()
    {
        if ( sessionFactory != null )
        {
            sessionFactory.close();
        }
    }
    @Override
    public Iterable<Mesaj> findAll() {
        return null;
    }

    @Override
    public void save(Mesaj entity) {
        try(Session session = sessionFactory.openSession())
        {
            Transaction tx=null;
            try{
                tx = session.beginTransaction();
                session.save(entity);
                tx.commit();
            }catch(RuntimeException ex){
                if (tx!=null)
                    tx.rollback();
            }
        }
    }

    @Override
    public void delete(Long aLong) {

    }

    @Override
    public void update(Mesaj entity) {

    }

    @Override
    public Iterable<Mesaj> findAllID(Long ang) {
        System.out.println("BDUIQWBDOIQ");
        List<Mesaj> mesajs = new ArrayList<>();
        try(Session session = sessionFactory.openSession())
        {

            Transaction tx=null;
            try{
                tx = session.beginTransaction();
                mesajs = session.createQuery("FROM Mesaj WHERE Task="+ang, Mesaj.class).list();
                System.out.println( mesajs.size() + " mesaj(s) found:" );
                tx.commit();
            }
            catch(RuntimeException ex)
            {
                System.out.println(ex);
                if (tx!=null)
                    tx.rollback();
            }
        }

        return mesajs;
    }
}
