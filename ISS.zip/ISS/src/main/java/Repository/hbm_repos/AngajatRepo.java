package Repository.hbm_repos;

import Domain.Angajat;
import Repository.interfaces.RepositoryAngajat;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.ArrayList;
import java.util.List;

public class AngajatRepo implements RepositoryAngajat {

    private static SessionFactory sessionFactory;

    public AngajatRepo(SessionFactory sessionFactory) {

        AngajatRepo.sessionFactory = sessionFactory;
    }

    static void close()
    {
        if ( sessionFactory != null )
        {
            sessionFactory.close();
        }
    }

    @Override
    public Angajat findAngajat(String user, String pw,String data) {
        Angajat angajat=null;
        try(Session session = sessionFactory.openSession())
        {

            Transaction tx=null;
            try
            {
                tx = session.beginTransaction();
                angajat = session.createQuery("FROM Angajat WHERE user =:S AND pw=:P", Angajat.class).setParameter("S",user).setParameter("P",pw).setMaxResults(1).uniqueResult();
                tx.commit();
            }
            catch(RuntimeException ex)
            {
                if (tx!=null)
                    tx.rollback();
            }
        }
        return angajat;
    }

    @Override
    public Angajat findOne(Long aLong) {
        Angajat angajat=null;
        try(Session session = sessionFactory.openSession())
        {

            Transaction tx=null;
            try
            {
                tx = session.beginTransaction();
                angajat = session.createQuery("FROM Angajat WHERE id = "+aLong, Angajat.class).setMaxResults(1).uniqueResult();
                tx.commit();
            }
            catch(RuntimeException ex)
            {
                if (tx!=null)
                    tx.rollback();
            }
        }
        return angajat;
    }

    @Override
    public Iterable<Angajat> findAll() {
        List<Angajat> angajats = new ArrayList<>();
        try(Session session = sessionFactory.openSession())
        {

            Transaction tx=null;
            try{
                tx = session.beginTransaction();
                angajats = session.createQuery("FROM Angajat", Angajat.class).list();
                System.out.println( angajats.size() + " angajat(s) found:" );
                tx.commit();
            }
            catch(RuntimeException ex)
            {
                if (tx!=null)
                    tx.rollback();
            }
        }
        return angajats;
    }

    @Override
    public void save(Angajat entity) {

    }

    @Override
    public void delete(Long aLong) {

    }

    @Override
    public void update(Angajat entity) {
        try(Session session = sessionFactory.openSession())
        {
            Transaction tx=null;
            try{
                tx = session.beginTransaction();
                session.update(entity);
                tx.commit();
            } catch(RuntimeException ex){
                if (tx!=null)
                    tx.rollback();
            }
        }
    }
}
