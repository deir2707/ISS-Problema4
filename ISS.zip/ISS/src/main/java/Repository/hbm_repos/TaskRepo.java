package Repository.hbm_repos;


import Domain.Task;
import Repository.interfaces.RepositoryTask;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.ArrayList;
import java.util.List;

public class TaskRepo implements RepositoryTask {
    private static SessionFactory sessionFactory;


    public TaskRepo(SessionFactory sessionFactory) {

        TaskRepo.sessionFactory = sessionFactory;
    }
    static void close()
    {
        if ( sessionFactory != null )
        {
            sessionFactory.close();
        }
    }

    @Override
    public Task findOne(Long aLong) {
        Task task = null;
        try(Session session = sessionFactory.openSession())
        {

            Transaction tx=null;
            try
            {
                tx = session.beginTransaction();
                task = session.createQuery("FROM Task WHERE id = "+aLong, Task.class).setMaxResults(1).uniqueResult();
                tx.commit();
            }
            catch(RuntimeException ex)
            {
                if (tx!=null)
                    tx.rollback();
            }
        }
        return task;
    }

    @Override
    public Iterable<Task> findAll() {
        System.out.println("BDUIQWBDOIQ");
        List<Task> tasks = new ArrayList<>();
        try(Session session = sessionFactory.openSession())
        {

            Transaction tx=null;
            try{
                tx = session.beginTransaction();
                tasks = session.createQuery("FROM Task", Task.class).list();
                System.out.println( tasks.size() + " task(s) found:" );
                tx.commit();
            }
            catch(RuntimeException ex)
            {
                System.out.println(ex);
                if (tx!=null)
                    tx.rollback();
            }
        }

        return tasks;
    }

    @Override
    public void save(Task entity) {
        try(Session session = sessionFactory.openSession())
        {
            Transaction tx=null;
            try{
                tx = session.beginTransaction();
                session.save(entity);
                tx.commit();
            }catch(RuntimeException ex){
                if (tx!=null)
                    tx.rollback();
            }
        }
    }

    @Override
    public void delete(Long aLong) {
        try(Session session = sessionFactory.openSession()){
            Transaction tx=null;
            try{
                tx = session.beginTransaction();
                Task task= session.createQuery("FROM Task WHERE id="+aLong, Task.class).setMaxResults(1).uniqueResult();
                System.out.println("Delete the task"+task);
                session.delete(task);
                tx.commit();
            } catch(RuntimeException ex){
                if (tx!=null)
                    tx.rollback();
            }
        }
    }

    @Override
    public void update(Task entity) {
        try(Session session = sessionFactory.openSession())
        {
            Transaction tx=null;
            try{
                tx = session.beginTransaction();
                session.update(entity);
                tx.commit();
            } catch(RuntimeException ex){
                if (tx!=null)
                    tx.rollback();
            }
        }
    }

    @Override
    public Iterable<Task> findDupaIdAngajatului(Long id, String stare) {
        return null;
    }
}
