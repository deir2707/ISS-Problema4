package Domain;

public class AngajatDTO {
    private String nume;
    private String data;

    public AngajatDTO(String nume, String data) {
        this.nume = nume;
        this.data = data;
    }

    public String getNume() {
        return nume;
    }

    public String getData() {
        return data;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setData(String data) {
        this.data = data;
    }
}
