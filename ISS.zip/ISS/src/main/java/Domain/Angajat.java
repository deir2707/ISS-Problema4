package Domain;

import java.util.Date;

public class Angajat extends Entity<Long> {
    private String nume;
    private String user;
    private String pw;
    private String rol;
    private String date;
    public Angajat() {
    }
    public Angajat(String nume, String user, String pw, String rol, String date) {
        this.nume = nume;
        this.user = user;
        this.pw = pw;
        this.rol = rol;
        this.date = date;
    }

    public String getNume() {
        return nume;
    }

    public String getUser() {
        return user;
    }

    public String getPw() {
        return pw;
    }

    public String getRol() {
        return rol;
    }

    public String getDate() {
        return date;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
