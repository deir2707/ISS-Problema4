package Domain;

import java.util.List;

public class Task extends Entity<Long> {
    private Long Sef;
    private String descriere;
    private String idAng;
    private String stare;

    public Task() {
    }
    public Task(Long sef, String descriere, String idAng,String stare) {
        Sef = sef;
        this.descriere = descriere;
        this.idAng = idAng;
        this.stare=stare;
    }

    public String getStare() {
        return stare;
    }

    public void setStare(String stare) {
        this.stare = stare;
    }

    public Long getSef() {
        return Sef;
    }

    public void setSef(Long sef) {
        Sef = sef;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public void setIdAng(String idAng) {
        this.idAng = idAng;
    }

    public String getDescriere() {
        return descriere;
    }

    public String getIdAng() {
        return idAng;
    }
}
