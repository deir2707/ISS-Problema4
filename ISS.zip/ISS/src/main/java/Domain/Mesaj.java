package Domain;

public class Mesaj extends Entity<Long> {
    private Long task;
    private String mesaj;
    private Long emitator;
    public Mesaj() {
    }
    public Mesaj(Long task, String mesaj, Long emitator) {
        this.task = task;
        this.mesaj = mesaj;
        this.emitator = emitator;
    }

    public Long getTask() {
        return task;
    }

    public String getMesaj() {
        return mesaj;
    }

    public Long getEmitator() {
        return emitator;
    }

    public void setTask(Long task) {
        this.task = task;
    }

    public void setMesaj(String mesaj) {
        this.mesaj = mesaj;
    }

    public void setEmitator(Long emitator) {
        this.emitator = emitator;
    }
}
