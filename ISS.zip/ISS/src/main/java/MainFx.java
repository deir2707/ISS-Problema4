import Controller.LogInController;
import Repository.hbm_repos.AngajatRepo;
import Repository.hbm_repos.MesajRepo;
import Repository.hbm_repos.TaskRepo;
import Repository.interfaces.RepositoryAngajat;
import Repository.interfaces.RepositoryMesaj;
import Repository.interfaces.RepositoryTask;
import Service.Service;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class MainFx extends Application {
    static SessionFactory initialize()
    {

        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure("h.xml") // configures settings from h.xml
                .build();
        try {
            return new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e)
        {
            System.err.println("Exception "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
        return null;
    }
    @Override
    public void start (Stage primaryStage ) throws Exception{

        SessionFactory s = initialize();
        if(s==null)
            throw new RuntimeException("Invalid session!");

        TaskRepo repotask=new TaskRepo(s);
        MesajRepo repomesaj=new MesajRepo(s);
        AngajatRepo repoangajat=new AngajatRepo(s);
        Service s1=new Service(repoangajat,repomesaj,repotask);
        try{

            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("/Login.fxml"));
            AnchorPane root=loader.load();
            LogInController logInController=loader.getController();
            primaryStage.setScene(new Scene(root,600,400, Color.TRANSPARENT));
            primaryStage.setTitle("App");
            logInController.setService(s1,primaryStage);
            primaryStage.show();
        }
        catch(Exception e)
        {
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error ");
            alert.setContentText("Error while starting app "+e);
            alert.showAndWait();
            e.printStackTrace();
        }
    }
    public static void main(String[] args){ launch(args);}

}