package Service;

public interface Observer
{
    public void update();
}
