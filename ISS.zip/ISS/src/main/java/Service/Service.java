package Service;



import Domain.Angajat;
import Repository.hbm_repos.AngajatRepo;
import Repository.hbm_repos.MesajRepo;
import Repository.hbm_repos.TaskRepo;
import Repository.interfaces.RepositoryAngajat;
import Repository.interfaces.RepositoryMesaj;
import Repository.interfaces.RepositoryTask;

import java.util.ArrayList;
import java.util.List;

public class Service implements IService
{
    private RepositoryAngajat repoangajat;
    private RepositoryMesaj repomesaj;
    private RepositoryTask repotask;
    private List<Observer> observers = new ArrayList<>();

    public Service(AngajatRepo repoangajat, MesajRepo repomesaj, TaskRepo repotask) {
        this.repoangajat = repoangajat;
        this.repomesaj = repomesaj;
        this.repotask = repotask;
    }


    public Iterable<Angajat> findAngajati(){
        return repoangajat.findAll();
    }
    @Override
    public Angajat login(String user, String password,String ora) {
        Angajat a= repoangajat.findAngajat(user,password,ora);
        if(a.getRol().equals("angajat"))
        {
            a.setDate("IN;"+ora);
        }

        repoangajat.update(a);
        for(Observer o : observers)
        {
            o.update();
        }
        return a;
    }

    @Override
    public void logout(Angajat a,String ora) {
        a.setDate("OUT;"+ora);
        repoangajat.update(a);
        for(Observer o : observers)
        {
            o.update();
        }
    }
    @Override
    public void addObserver(Observer o) {
        if(o!=null) observers.add(o);
    }

    @Override
    public void removeObserver(Observer o) {
        observers.remove(o);
    }
}
