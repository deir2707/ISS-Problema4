package Service;

import Domain.*;

public interface IService extends Observable
{
    public Angajat login(String user,String password,String ora);
    public void logout(Angajat a,String ora);

}
