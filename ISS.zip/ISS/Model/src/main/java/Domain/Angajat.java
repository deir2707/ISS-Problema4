package Domain;

public class Angajat {
}
